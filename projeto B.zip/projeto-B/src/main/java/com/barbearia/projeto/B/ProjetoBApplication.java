package com.barbearia.projeto.B;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoBApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoBApplication.class, args);
	}

}
